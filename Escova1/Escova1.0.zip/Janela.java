import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import javax.swing.event.*;

public class Janela extends JInternalFrame
{
	JDesktopPane desktop;
	public Janela(JDesktopPane desktop)
	{
		super("Estivador");
		this.desktop=desktop;
		//setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		//System.out.println(DO_NOTHING_ON_CLOSE);
		
		//desktop = new JDesktopPane();

		
    /*addWindowListener(new WindowAdapter()
    {
    	public void windowClosing(WindowEvent e){System.exit(0);}
    });*/
    
    //JPanel jogo=new JPanel();
    Meupanel jogo=new Meupanel(/*this*/);
    getContentPane().add(jogo,BorderLayout.CENTER);
    //jogo.repaint();
    //JPanel chat=new JPanel();
    
    //nomej.setPreferredSize(new Dimension(175, 100));
    
    
    //MeuMenu m =new MeuMenu(this, desktop);     
    
    //setContentPane(desktop);
        
    //Arrastamento mais r�pido
    //desktop.putClientProperty("JDesktopPane.dragMode", "outline");
    
    setSize(700,500);
    setLocation(50,50);
    adicionaChat();
    
    //pack();
    //show();
    desktop.add(this);
    setVisible(true);
  }
	public void adicionaChat()
	{
		JButton send=new JButton("enviar mensagem");
		send.setMnemonic('s');
		//jp.add(sai);
    //sai.setToolTipText("Clique aqui para desconectar");
    send.setToolTipText("Clique aqui para enviar sua mensagem!");
		JTextField msg=new JTextField(30);
		msg.setToolTipText("Digite aqui sua mensagem!");
		JPanel jp =new JPanel();
		jp.setBackground(Color.red);
		JLabel nomej = new JLabel("Aham");
    jp.add(nomej/*,BorderLayout.SOUTH*/);
		jp.add(msg);
		jp.add(send);
		jp.setLayout(new FlowLayout());
		//jp.setVisible(true);
		getContentPane().add(jp,BorderLayout.SOUTH);
	}
	/**Cria um botao para desconectar e outro para enviar msg
	*com respectivas shortkeys 'd' & 'e'.*/
}
/*public class ButtonDemo extends JPanel
                        implements ActionListener {
    protected JButton b1, b2, b3;

    public ButtonDemo() {
        ImageIcon leftButtonIcon = new ImageIcon("images/right.gif");
        ImageIcon middleButtonIcon = new ImageIcon("images/middle.gif");
        ImageIcon rightButtonIcon = new ImageIcon("images/left.gif");

        b1 = new JButton("Disable middle button", leftButtonIcon);
        b1.setVerticalTextPosition(AbstractButton.CENTER);
        b1.setHorizontalTextPosition(AbstractButton.LEFT);
        b1.setMnemonic(KeyEvent.VK_D);
        b1.setActionCommand("disable");

        b2 = new JButton("Middle button", middleButtonIcon);
        b2.setVerticalTextPosition(AbstractButton.BOTTOM);
        b2.setHorizontalTextPosition(AbstractButton.CENTER);
        b2.setMnemonic(KeyEvent.VK_M);

        b3 = new JButton("Enable middle button", rightButtonIcon);
        //Use the default text position of CENTER, RIGHT.
        b3.setMnemonic(KeyEvent.VK_E);
        b3.setActionCommand("enable");
        b3.setEnabled(false);

        //Listen for actions on buttons 1 and 3.
        b1.addActionListener(this);
        b3.addActionListener(this);

        b1.setToolTipText("Click this button to disable the middle button.");
        b2.setToolTipText("This middle button does nothing when you click it.");
        b3.setToolTipText("Click this button to enable the middle button.");

        //Add Components to this container, using the default FlowLayout. 
        add(b1);
        add(b2);
        add(b3);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("disable")) {
            b2.setEnabled(false);
            b1.setEnabled(false);
            b3.setEnabled(true);
        } else { 
            b2.setEnabled(true);
            b1.setEnabled(true);
            b3.setEnabled(false);
        }
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("ButtonDemo");

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.getContentPane().add(new ButtonDemo(), BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
    }*/
	/*public void ajeitarAcao()
	{
		in=new Recebimento(ta,jl,c);
		in.start();
		b.addActionListener (new Envio(ta,msg,jl,c));
		
		sai.addActionListener(new ActionListener() 
		{ 	
			public void actionPerformed(ActionEvent e)
			{
				c.fechaConexao();
				in.stop();
				dispose();
			}
		});
	}
}*/