import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import javax.swing.event.*;

class Meupanel extends Canvas
{
	public Meupanel(/*JInternalFrame f*/)
	{
		super();
		setSize(10,100);
    //setLocation(65,65);
    setBackground(Color.green);
    //adicionaChat();
    
    //pack();
    //show();
    //desktop.add(this);
    //f.add(this,BorderLayout.NORTH);
    setVisible(true);
	}
	public void paint(Graphics g){g.drawImage(Toolkit.getDefaultToolkit().getImage("d:\\java\\escova\\cartas\\10copas.jpg"),70,70,this);}
}
	