import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import javax.swing.event.*;

public class Fundo extends JFrame
{
	//private JButton send;
	//private JTextField msg;
	JDesktopPane desktop;
	
	public Fundo()
	{
		super("Jogo de Escova - NET");
		
		//setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		//System.out.println(DO_NOTHING_ON_CLOSE);
		
		desktop = new JDesktopPane();
		
    addWindowListener(new WindowAdapter()
    {
    	public void windowClosing(WindowEvent e){System.exit(0);}
    });
    
    //JLabel nomej = new JLabel("Aham");
    //nomej.setPreferredSize(new Dimension(175, 100));
    //getContentPane().add(nomej, BorderLayout.SOUTH);
    
    Menu m =new Menu(this, desktop);
    setContentPane(desktop);
    //Arrastamento mais r�pido
    desktop.putClientProperty("JDesktopPane.dragMode", "outline");
    
    setSize(750,550);
    setLocation(20,20);
    //adicionaPanelSul();
    
    //pack();
    //show();
    setVisible(true);
  }
}