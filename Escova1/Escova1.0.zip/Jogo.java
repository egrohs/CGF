import java.util.*;
import java.math.*;

class Jogo
{
	private String naipes[]={"Ouro","Paus","Copas","Espadas"};
	private Vector baralho=new Vector();
	private Vector mesa=new Vector();
	private Vector players=new Vector();
	private Vector pcs=new Vector();
	
	//private int pos;
	
	public Jogo(int nplayers, String nomes[])
	{
		//for(int i=0;i<nplayers;i++)
			//players.addElement(new Player(nomes[i]));//arrumar para pc e player
			pcs.addElement(new Pc());
			players.addElement(new Jogador("Estivador"));//
		start();
	}
	public void start()
	{
		for(int v=1;v<=10;v++)//cria baralho
		{
			//System.out.println("Oi");
			for(int n=0;n<4;n++)
			{
				Carta c=new Carta(v,naipes[n]);
				mesa.addElement(c);
				//System.out.println("Val= "+c.getValor()+"Naip= "+c.getNaipe());
			}
		}
		for(int i=40;i>0;i--)//embaralha
		{
			int pos=(int)(Math.random()*i);
			//System.out.println("Pos= "+pos);
			baralho.addElement((Carta)mesa.elementAt(pos));
			mesa.removeElementAt(pos);
		}
		for(int i=0;i<4;i++)//bota a mesa
		{
			mesa.addElement((Carta)baralho.elementAt(0));
			baralho.removeElementAt(0);
		}
		
		Pc pc=(Pc)pcs.elementAt(0);
		Jogador pl=(Jogador)players.elementAt(0);
		damaos();
		Vector maopc=(Vector)pc.getMao();
		Vector maojog=(Vector)pl.getMao();
		System.out.println("MESA: ");
		for(int l=0;l<mesa.size();l++)//mostra mesa
		{
			Carta t=(Carta)mesa.elementAt(l);
			System.out.println(l+")=["+t.getValor()+" "+t.getNaipe()+"]");
		}
		/*for(int l=0;l<baralho.size();l++)//mostra baralho
		{
			Carta t=(Carta)baralho.elementAt(l);
			System.out.println("Val= "+t.getValor()+"Naip= "+t.getNaipe());
		}*/
		System.out.println("SUA MAO: ");
			for(int l=0;l<maojog.size();l++)//mostra mao do player
			{
				Carta p=(Carta)maojog.elementAt(l);
				System.out.println(l+")=["+p.getValor()+" "+p.getNaipe()+"]");
			}
		//daqui pra baixo, ta tudo provisorio, mudar tudo
		int nroj=0;
		do//joga n vezes
		{
			if(maojog.size()==0)
			{
				System.out.println("-----------------Rodada= "+nroj);
				nroj++;
				damaos();
			}
			pc.criaJogadas(mesa);
			mesa=pc.melhorJogada(pl,mesa);
			if(mesa.size()==0)pc.setEscova();//entao fez escova
			maojog=(Vector)pl.getMao();
			System.out.println("MESA: ");
			for(int l=0;l<mesa.size();l++)//mostra mesa
			{
				Carta t=(Carta)mesa.elementAt(l);
				System.out.println(l+")=["+t.getValor()+" "+t.getNaipe()+"]");
			}
			System.out.println("SUA MAO: ");
			for(int l=0;l<maojog.size();l++)//mostra mao do player
			{
				Carta p=(Carta)maojog.elementAt(l);
				System.out.println(l+")=["+p.getValor()+" "+p.getNaipe()+"]");
			}
			
			if(maojog.size()>0)
			{
				Vector jog=new Vector();
				while(true)
				{
					int opc=Console.readInt("Numero da Carta: ");
					if(opc!=-1)
						jog.addElement(new Integer(opc));
					else break;
				}
				mesa=pl.fazJogada(pc,jog,mesa);
				if(mesa.size()==0)pl.setEscova();//entao fez escova
			}
			
		}while(baralho.size()>0 || maojog.size()>0);
		
		while(mesa.size()>0)
		{
			Carta c=(Carta)mesa.elementAt(0);
			if(pl.getUlt()==true)
				pl.setMonte(c);
			else pc.setMonte(c);
			mesa.removeElementAt(0);
		}
		
		int jogpont=0,pont=0,ouro=0,setes=0;
		Vector mpc=pc.getMonte();
		Vector mjog=pl.getMonte();
		Carta h;
		
		System.out.println("mpc= "+mpc.size());
		System.out.println("mjog= "+mjog.size());
		
		for(int l=0;l<mpc.size();l++)
		{	
			h=(Carta)mpc.elementAt(l);
			if(h.getValor()==7 && h.getNaipe().equals("Ouro"))
				pont++;
			if(h.getNaipe().equals("Ouro"))
				ouro++;
			if(h.getValor()==7)
				setes++;
		}
		if(setes>=3)
			pont++;
		if(ouro>=6)
			pont++;
			
		ouro=0;setes=0;
		
		for(int l=0;l<mjog.size();l++)
		{	
			h=(Carta)mjog.elementAt(l);
			if(h.getValor()==7 && h.getNaipe().equals("Ouro"))
				jogpont++;
			if(h.getNaipe().equals("Ouro"))
				ouro++;
			if(h.getValor()==7)
				setes++;
		}

		if(setes>=3)
			jogpont++;
		if(ouro>=6)
			jogpont++;
			
		if(mpc.size()>20)
			pont++;
		if(mjog.size()>20)
			jogpont++;
		pont+=pc.getEscova();	
		jogpont+=pl.getEscova();
		pc.setPontos(pont);
		pl.setPontos(jogpont);
		System.out.println("Pc Pontos= "+pont);
		System.out.println("Jog Pontos= "+jogpont);
		
/*		for(int i=0;i<j.size();i++)
		{
			Vector jog=(Vector)j.elementAt(i);
			for(int k=0;k<jog.size();k++)
			{
				Carta c=(Carta)jog.elementAt(k);
				System.out.println("Jogada "+i+"=> Valor = "+c.getValor()+" => Naipe"+c.getNaipe());
			}
		}*/
	}
	public void damaos()
	{
		//falta zerar o vetor de jogadas!!!
		for(int i=0;i<players.size();i++)
		{
			Jogador p=(Jogador)players.elementAt(i);
			for(int j=0;j<3;j++)//bota as maos de todos players
			{
				p.setMao((Carta)baralho.elementAt(0));
				baralho.removeElementAt(0);
			}
		}
		for(int i=0;i<players.size();i++)
		{
			Pc pc=(Pc)pcs.elementAt(i);
			for(int j=0;j<3;j++)//bota as maos de todos pcs
			{
				pc.setMao((Carta)baralho.elementAt(0));
				baralho.removeElementAt(0);
			}
		}
	}
	
	public Vector ordenaVector(Vector v)//nao esta sendo usado
	{
		Vector t=new Vector();
		int men;
		while(v.size()>0)
		{
			men=0;
			for(int j=0;j<v.size();j++)
			{
				Carta c1=(Carta)v.elementAt(men);
				Carta c2=(Carta)v.elementAt(j);
				if(c2.getValor()<c1.getValor())
					men=j;
			}
			t.addElement((Carta)v.elementAt(men));
			v.removeElementAt(men);
		}
		return t;
	}
}