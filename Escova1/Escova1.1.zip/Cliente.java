import java.rmi.*;
class Cliente
{
	
}