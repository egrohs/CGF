import java.rmi.*;
public interface RMInterface extends Remote
{
	public void Seila()throws RemoteException;
}