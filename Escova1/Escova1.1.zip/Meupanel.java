import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import javax.swing.event.*;

class Meupanel extends Canvas
{
	private Vector mao=new Vector();
	private Vector mesa=new Vector();
		
	public Meupanel(Vector mao, Vector mesa)
	{
		super();
		this.mao=mao;
		this.mesa=mesa;
    setBackground(Color.green);
    setVisible(true);
	}
	public void paint(Graphics g)
	{
		for(int i=0;i<mao.size();i++)
		{
			Carta c=(Carta)mao.elementAt(i);
			int valor= c.getValor();
			String naipe=c.getNaipe();
			String s=Integer.toString(valor);
			System.out.println(""+s);
			//int pos=Integer.parseInt(itg.toString());
		}
		g.drawImage(Toolkit.getDefaultToolkit().getImage("d:\\java\\escova\\cartas\\10copas.jpg"),70,70,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage("d:\\java\\escova\\cartas\\10copas.jpg"),70,70,this);
		
	}
}
	