import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import javax.swing.event.*;

public class Janela extends JInternalFrame
{
	JDesktopPane desktop;
	String nomes[]={"PC","Estivador"};
	
	public Janela(JDesktopPane desktop)
	{
		super("Jogo de Estivador");
		this.desktop=desktop;
		Jogo j = new Jogo(2,nomes);//
    //Meupanel jogo=new Meupanel();
    //getContentPane().add(jogo,BorderLayout.CENTER);
    setSize(700,500);
    setLocation(50,50);
    adicionaChat();
    desktop.add(this);
    setVisible(true);
  }
  
	public void adicionaChat()
	{
		JButton send=new JButton("enviar mensagem");
		send.setMnemonic('s');
    send.setToolTipText("Clique aqui para enviar sua mensagem!");
		JTextField msg=new JTextField(30);
		msg.setToolTipText("Digite aqui sua mensagem!");
		JPanel jp =new JPanel();
		jp.setBackground(Color.red);
		JLabel nomej = new JLabel("Aham");
    jp.add(nomej);
		jp.add(msg);
		jp.add(send);
		jp.setLayout(new FlowLayout());
		getContentPane().add(jp,BorderLayout.SOUTH);
	}
}