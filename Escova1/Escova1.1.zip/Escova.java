class Escova
{
	public static void main(String s[])
	{
		String nomes[]={"PC","Estivador"};
		Fundo f=new Fundo();
		//Jogo j = new Jogo(2,nomes);
	}
}